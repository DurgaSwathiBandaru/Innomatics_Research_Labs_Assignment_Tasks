from flask import Flask, request, render_template_string
import re

app = Flask(__name__)

# HTML template stored in Python (no separate file)
html_content = """
<!DOCTYPE html>
<html>
<head>
    <title>Regex Matcher Project</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        h2 { color: #2c3e50; }
        input[type=text] { width: 300px; padding: 5px; }
        input[type=submit] { padding: 5px 15px; background-color: #3498db; color: white; border: none; cursor: pointer; }
        ul { color: green; }
        p { color: red; }
    </style>
</head>
<body>
    <h2>Regex Matcher App</h2>
    <form method="GET">
        <label>Test String:</label><br>
        <input type="text" name="test_string" required><br><br>
        <label>Regular Expression:</label><br>
        <input type="text" name="regex" required><br><br>
        <input type="submit" value="Submit">
    </form>

    {% if matches is not none %}
        <h3>Matched Strings:</h3>
        {% if matches %}
            <ul>
                {% for match in matches %}
                    <li>{{ match }}</li>
                {% endfor %}
            </ul>
        {% else %}
            <p>No matches found!</p>
        {% endif %}
    {% endif %}
</body>
</html>
"""

@app.route("/", methods=["GET"])
def match_regex():
    test_string = request.args.get("test_string")
    pattern = request.args.get("regex")
    matches = None
    if test_string and pattern:
        try:
            matches = re.findall(pattern, test_string)
        except re.error:
            matches = ["Invalid regex pattern!"]
    return render_template_string(html_content, matches=matches)

if __name__ == "__main__":
    app.run(debug=True)
