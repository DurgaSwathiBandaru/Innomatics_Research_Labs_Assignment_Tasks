from flask import Flask, request

app = Flask(__name__)

@app.route("/user")
def user():
    name = request.args.get("name")
    if not name:
        return "Please provide your name like ?name=YourName"
    return f"HELLO {name.upper()} 👋"

if __name__ == "__main__":
    app.run(debug=True)
